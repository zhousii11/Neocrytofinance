import React from "react";

export default function App() {
  return (
    <div className="h-screen flex items-center justify-center bg-black text-green-400 text-3xl">
      NeoCryptoFinance — Plataforma Base Instalada
    </div>
  );
}
